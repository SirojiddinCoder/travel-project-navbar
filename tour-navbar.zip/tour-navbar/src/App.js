import React from 'react';
import './App.css';
import { Home } from './Components/Home';
import { About } from './Components/About';


function App() {
  return (
   <div className="header">
     <div className="App">
     <Home />
    
    </div>
   </div>
  );
}

export default App;
