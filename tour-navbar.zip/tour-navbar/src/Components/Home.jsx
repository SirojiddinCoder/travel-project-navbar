import React from 'react'
import { Navbar } from './Navbar'

export const Home = () => {
  return (
   <div className="header">
     <div className="home-container">
        <Navbar/>
    </div>
   </div>
  ) 
}
