import React from 'react'

export const Contacts = () => {
  return (
    <div>Contacts</div>
  )
}

