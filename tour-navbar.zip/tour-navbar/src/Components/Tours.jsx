import React from 'react'

export const Tours = () => {
  return (
    <div>Tours</div>
  )
}
